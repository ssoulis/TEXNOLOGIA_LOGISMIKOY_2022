This is the zip file for the 1st part of Project Texnologia Logismikou 2022

You can also watch the progress we've made from the branch paradoteo-v1 
on github following this link : 
https://github.com/ssoulis/TEXNOLOGIA_LOGISMIKOY_2022/tree/paradoteo-v1